/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package srs;

/**
 *
 * @author ycefq
 */
public class School {
    private int id;
    private String name;
    private String abrv;
    
    public School(int id, String name, String abrv){
        this.id = id;
        this.name = name;
        this.abrv = abrv;
    }
}
